/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.ufrsciencestech.panier;

/**
 *
 * @author md405778
 */
public interface Fruit {
    public double getPrix();
    public String getOrigine();
    public void setPrix(double p);
    public void setOrigine(String s);
}
